java -jar data_exploration-1.0-SNAPSHOT-jar-with-dependencies.jar
