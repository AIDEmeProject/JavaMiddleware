docker build . -t aideplus && docker run -p 7060:7060 --rm aideplus
