docker build . -t aideplus && docker run -d -p 7060:7060 --rm aideplus
