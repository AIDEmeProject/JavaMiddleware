self.__precacheManifest = [
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "ef7af40d7706b82694ab",
    "url": "/static/js/main.ef7af40d.chunk.js"
  },
  {
    "revision": "85ce8360f3e6bc7ded2c",
    "url": "/static/js/1.85ce8360.chunk.js"
  },
  {
    "revision": "ef7af40d7706b82694ab",
    "url": "/static/css/main.f7107ce8.chunk.css"
  },
  {
    "revision": "40803f00eb68b4b157294fb97fa0ea4a",
    "url": "/index.html"
  }
];