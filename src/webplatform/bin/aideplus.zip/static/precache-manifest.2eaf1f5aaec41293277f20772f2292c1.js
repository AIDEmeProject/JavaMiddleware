self.__precacheManifest = [
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "1d070d9d3ba7b96d9c00",
    "url": "/static/js/main.1d070d9d.chunk.js"
  },
  {
    "revision": "64424e81d452d400ca8a",
    "url": "/static/js/1.64424e81.chunk.js"
  },
  {
    "revision": "1d070d9d3ba7b96d9c00",
    "url": "/static/css/main.1a424bae.chunk.css"
  },
  {
    "revision": "8001a8adc88202ed60683cf8d98ba7a6",
    "url": "/index.html"
  }
];