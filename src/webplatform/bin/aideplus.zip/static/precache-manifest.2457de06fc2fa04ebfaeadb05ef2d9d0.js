self.__precacheManifest = [
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "0b4e90497e97eac10a28",
    "url": "/static/js/main.0b4e9049.chunk.js"
  },
  {
    "revision": "624cdbb2c4a1354406dc",
    "url": "/static/js/1.624cdbb2.chunk.js"
  },
  {
    "revision": "0b4e90497e97eac10a28",
    "url": "/static/css/main.30b872a4.chunk.css"
  },
  {
    "revision": "209569ed1e6d286eaa60fe8c53b9f1f6",
    "url": "/index.html"
  }
];